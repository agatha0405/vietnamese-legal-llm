"""Look up reviewed provisions separately from the QLoRA training data."""

from dataclasses import dataclass
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
import re
import tomllib
import unicodedata
from urllib.parse import urlparse

if __package__:
    from .inference import CLARIFY_VEHICLE, NO_SANCTION_SOURCE, ROAD_CONTEXT, SANCTION, VEHICLE
else:
    from inference import CLARIFY_VEHICLE, NO_SANCTION_SOURCE, ROAD_CONTEXT, SANCTION, VEHICLE


SOURCE_FILE = Path(__file__).with_name("legal_sources.toml")
VIETNAM_TIME = timezone(timedelta(hours=7))
OUTSIDE = re.compile(
    r"\b(đăng ký kết hôn|ly hôn|thuế thu nhập|kê khai thuế|dự báo thời tiết|"
    r"có mưa không|quyền tác giả|thừa kế|phi công|xuất cảnh bằng đường hàng không)\b"
)
FOREIGN = re.compile(r"\b(ở|tại|luật|pháp luật) (nhật bản|pháp|mỹ|hoa kỳ|anh quốc|thái lan|hàn quốc|trung quốc)\b")
VIETNAM = re.compile(r"\b(việt nam|trong nước)\b")
MOTO = re.compile(r"\b(xe (máy|gắn máy)|mô tô)\b")
CAR = re.compile(r"\b(ô\s*tô|xe (tải|con|buýt|khách|bán tải|đầu kéo))\b")
BICYCLE = re.compile(r"\bxe đạp(?: máy)?\b(?! điện)")
SPECIAL = re.compile(r"\bxe máy chuyên dùng\b")
OTHER_VEHICLE = re.compile(r"\b(xe (điện|đạp điện|máy điện|bốn bánh|4 bánh|ba bánh|3 bánh)|đi bộ)\b")
EXTRA_MOTO = re.compile(r"\bxe máy (điện|chuyên dùng)\b")
ACCIDENT = re.compile(r"\b(tai nạn|va chạm|đâm|tông|thương tích|chết người|bị thương)\b")
NO_ACCIDENT = re.compile(r"\b(không|chưa) (gây |xảy ra |có )?(tai nạn|va chạm)\b")
MINOR = re.compile(r"\b(\d{1,2} tuổi|chưa thành niên|trẻ em|học sinh)\b")
EXPLICIT_DATE = re.compile(r"\b(\d{4})-(\d{2})-(\d{2})\b|\b(\d{1,2})[/-](\d{1,2})[/-](\d{4})\b")
OTHER_TIME = re.compile(
    r"\b(năm|tháng|trước|sau|từ)\s+20\d{2}\b|\b(năm sau|năm ngoái|hôm qua|ngày mai)\b|"
    r"\b\d{1,2}[/-]\d{1,2}\b|\btháng \d{1,2}\b"
)
CURRENT = re.compile(r"\b(hiện nay|hiện hành|hôm nay|mới nhất|bây giờ)\b")
FOLLOW_UP = re.compile(r"^(tôi (đi|lái|chạy) |còn |đi |lái )?(xe |ô tô|mô tô)")
FACT_REPLY = re.compile(r"^(có\b|vâng\b|đúng\b|(xe |tôi )?đang\b|tôi (có )?(cầm|dùng tay)\b|không\b)")
PENALTY_CUE = re.compile(r"\b(phạt|chế tài|án phạt|mức xử lý hành chính|tước|tịch thu|tạm giữ|đình chỉ|cảnh cáo)\b")
MONEY_REQUEST = re.compile(r"\b((mất|nộp|đóng|tốn|hết) (bao nhiêu|mấy)|bao nhiêu (tiền|đồng|điểm))\b")
OTHER_SANCTION = re.compile(r"\b(tước|tịch thu|tạm giữ|đình chỉ|cảnh cáo)\b")
POINTS_REQUEST = re.compile(r"\b(trừ|mất|bao nhiêu|mấy) (?:bao nhiêu |mấy )?điểm\b")
UNVERIFIED_AMOUNT = re.compile(
    r"(?:\d|\b(?:một|hai|ba|bốn|tư|năm|sáu|bảy|tám|chín|mười|vài|trăm|nghìn|ngàn)\b)"
    r"[\d\s.,–—-]*(?:triệu|nghìn|ngàn|tỷ|vnd|vnđ|đồng|đ\b|k\b|tr\b|điểm)|"
    r"\b(phạt|tước|trừ)\b[^\n.!?]{0,45}\d|[罚罰扣][^\n]{0,25}\d"
)


@dataclass(frozen=True)
class Decision:
    kind: str
    text: str
    rule: str | None = None
    citation: str | None = None
    url: str | None = None
    amendment_url: str | None = None

    def render(self):
        if not self.url:
            return self.text
        related = f"\nVăn bản sửa đổi hoặc hợp nhất đã đối chiếu: {self.amendment_url}" if self.amendment_url else ""
        return f"{self.text}\nCăn cứ: {self.citation}.\nNguồn: {self.url}{related}"


def normalize(text):
    return " ".join(unicodedata.normalize("NFC", text).casefold().split())


def sanction_intent(text, *, road_related=False):
    return bool(SANCTION.search(text) or PENALTY_CUE.search(text) or (road_related and MONEY_REQUEST.search(text)))


def unverified_sanction_output(text):
    """Detect common monetary and point claims in the ungrounded model fallback."""
    return bool(UNVERIFIED_AMOUNT.search(normalize(text)))


def official_url(url):
    parsed = urlparse(url)
    host = parsed.hostname or ""
    return parsed.scheme == "https" and (host == "chinhphu.vn" or host.endswith(".chinhphu.vn")
                                         or host == "vbpl.vn" or host.endswith(".vbpl.vn"))


def match_all(patterns, text):
    return all(re.search(pattern, text) for pattern in patterns)


def match_any(patterns, text):
    return any(re.search(pattern, text) for pattern in patterns)


def question_date(text, verified_through, today):
    matches = list(EXPLICIT_DATE.finditer(text))
    if len(matches) > 1:
        return None
    if matches:
        year, month, day, dmy_day, dmy_month, dmy_year = matches[0].groups()
        try:
            return date(int(year or dmy_year), int(month or dmy_month), int(day or dmy_day))
        except ValueError:
            return None
    if OTHER_TIME.search(text):
        return None
    return today if CURRENT.search(text) else verified_through


def vehicle_groups(question):
    groups = set()
    if MOTO.search(EXTRA_MOTO.sub("", question)):
        groups.add("moto")
    if CAR.search(question):
        groups.add("car")
    if BICYCLE.search(question):
        groups.add("bicycle")
    if SPECIAL.search(question):
        groups.add("special")
    if OTHER_VEHICLE.search(question) or (not groups and VEHICLE.search(question)):
        groups.add("other")
    return groups


class LegalIndex:
    def __init__(self, path=SOURCE_FILE):
        with path.open("rb") as source:
            self.data = tomllib.load(source)
        self.verified_through = self.data["verified_through"]
        for record in (*self.data["rules"], *self.data["provisions"]):
            doc = self.data["documents"][record["document"]]
            if not record["citation"].strip() or not official_url(doc["url"]):
                raise ValueError(f"Missing official citation for {record['id']}")
            if doc.get("amendment_url") and not official_url(doc["amendment_url"]):
                raise ValueError(f"Invalid amendment source for {record['id']}")

    def resolve(self, messages, *, today=None):
        question = normalize(messages[-1]["content"])
        outside_topic = OUTSIDE.search(question) and not (ROAD_CONTEXT.search(question) or VEHICLE.search(question))
        outside_country = FOREIGN.search(question) and not VIETNAM.search(question)
        if outside_topic or outside_country:
            return Decision("outside", "Câu hỏi này nằm ngoài phạm vi pháp luật giao thông đường bộ Việt Nam.")
        if len(messages) >= 4 and not sanction_intent(question):
            previous_reply = messages[-2]["content"]
            vehicle_reply = previous_reply == CLARIFY_VEHICLE and FOLLOW_UP.search(question)
            clarification = any(previous_reply == topic.get("clarification") for topic in self.data["topics"].values())
            if (vehicle_reply and len(question.split()) <= 8) or (clarification and FACT_REPLY.search(question)):
                question = f"{normalize(messages[-3]['content'])} {question}"
            elif sanction_intent(normalize(messages[-3]["content"]), road_related=True):
                if (MONEY_REQUEST.search(question) or question.startswith(("còn ", "thế ", "vậy "))
                        or re.fullmatch(r"(?:bao nhiêu|mấy tiền)[?!.]*", question)):
                    return Decision("no_source", NO_SANCTION_SOURCE)

        target_date = question_date(question, self.verified_through, today or datetime.now(VIETNAM_TIME).date())
        topics = [name for name, topic in self.data["topics"].items() if match_any(topic["matches"], question)]
        vehicles = vehicle_groups(question)
        road_related = bool(topics or vehicles or ROAD_CONTEXT.search(question))
        if sanction_intent(question, road_related=road_related):
            if not road_related:
                return Decision("no_source", NO_SANCTION_SOURCE)
            if OTHER_SANCTION.search(question):
                return Decision("no_source", NO_SANCTION_SOURCE)
            if len(vehicles) != 1:
                return Decision("clarify", CLARIFY_VEHICLE)
            if len(topics) != 1:
                return Decision("no_source", NO_SANCTION_SOURCE)
            topic = self.data["topics"][topics[0]]
            if (match_any(topic.get("exclude", ()), question) or ACCIDENT.search(NO_ACCIDENT.sub("", question))
                    or MINOR.search(question) or FOREIGN.search(question)):
                return Decision("no_source", NO_SANCTION_SOURCE)
            if not match_all(topic.get("facts", ()), question):
                return Decision("clarify", topic["clarification"])
            candidates = [r for r in self.data["rules"] if r["topic"] == topics[0] and r["vehicle"] in vehicles]
        else:
            candidates = [r for r in self.data["provisions"]
                          if match_all(r["matches"], question) and not match_any(r.get("exclude", ()), question)]
            if not candidates:
                return None
        matches = [r for r in candidates if target_date and r["effective_from"] <= target_date <= self.verified_through
                   and (not r.get("effective_to") or target_date < r["effective_to"])]
        if len(matches) != 1:
            return Decision("no_source", f"Chưa có căn cứ đã đối chiếu cho tình huống hoặc thời điểm này. Mốc rà soát nguồn: {self.verified_through:%d/%m/%Y}.")
        if POINTS_REQUEST.search(question) and "points" not in matches[0]:
            return Decision("no_source", NO_SANCTION_SOURCE)
        return self.render_rule(matches[0], target_date)

    def render_rule(self, rule, target_date):
        doc = self.data["documents"][rule["document"]]
        text = rule.get("fact")
        if "fine_vnd" in rule:
            condition = self.data["topics"][rule["topic"]]["condition"].lower()
            low, high = (f"{amount:,}".replace(",", ".") for amount in rule["fine_vnd"])
            text = f"Người điều khiển {rule['vehicle_label']} {condition} bị phạt từ {low} đến {high} đồng"
            if "points" in rule:
                text += f" và trừ {rule['points']} điểm giấy phép lái xe"
                if rule.get("points_condition"):
                    text += f" {rule['points_condition']}"
            text += "."
        text = f"{text}\nMốc áp dụng dùng để tra cứu: {target_date:%d/%m/%Y}."
        return Decision("grounded", text, rule["id"], f"{rule['citation']} {doc['number']}", doc["url"],
                        doc.get("amendment_url"))
